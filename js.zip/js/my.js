
//导航js
$(document).ready(function(){
   $(".menu_icon").click(function(){
       $(".nav").toggle();
   })

})

//文本输入框
$(document).ready(function(){
    $("input[type=text]").click(function(){
        $(this).val("");
    })

})

//tab切换
$(document).ready(function(){
    var $dian2=$(".storeNav li");
    $dian2.click(function(){
        $(this).addClass("hover").siblings().removeClass("hover");
        var index =$dian2.index(this);
        $("div.storeContaier > div").eq(index).show().siblings().hide();

    })
})

//详情切换
$(document).ready(function(){
    var $dian2=$(".proTitle li");
    $dian2.click(function(){
        $(this).addClass("hover").siblings().removeClass("hover");
        var index =$dian2.index(this);
        $("div.proC> div").eq(index).show().siblings().hide();

    })
})

$(document).ready(function(){
    var $dian2=$(".ping li");
    $dian2.click(function(){
        $(this).addClass("hover").siblings().removeClass("hover");
        var index =$dian2.index(this);
        $("div.pingBox> div").eq(index).show().siblings().hide();

    })
})